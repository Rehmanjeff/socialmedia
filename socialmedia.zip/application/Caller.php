<?php
Header('Location: monitor.php');
?>