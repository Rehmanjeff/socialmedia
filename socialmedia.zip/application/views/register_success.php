<h2>Success! Thanks for registering <?php echo $username?>, now please confirm your registeration from email</h2>
<br><a href="<?php echo base_url();?>index.php/login">Click to Login</a>