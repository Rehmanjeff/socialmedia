<h2>Registeration Complete, you can now login</h2>
<br><a href="<?php echo base_url();?>index.php/login">Click to Login</a>