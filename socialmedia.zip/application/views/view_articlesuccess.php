	<div class="row">
		<div class="col-xs-6">
			<?php
				// Display Result Using Ajax
				echo "<div class='alert alert-success' role='alert'>Post Added Successfully....!</div>";
				echo "</div>";
				echo "</div>";
			?>
		</div>
	</div>