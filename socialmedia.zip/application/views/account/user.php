<div class="container">
	<div class="row">
		<div class="col-xs-10">
			<h1>Welcome user</h1>
		</div>
	</div>
</div>